import * as React from "react"

const MOBILE_BREAKPOINT = 768

export function useIsMobile() {
  const [isMobile, setIsMobile] = React.useState<boolean | undefined>(undefined)

  React.useEffect(() => {
    const mql = window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT - 1}px)`)
    const onChange = () => {
      setIsMobile(window.innerWidth < MOBILE_BREAKPOINT)
    }
    mql.addEventListener("change", onChange)
    
    // Initial check moved to separate block if needed, 
    // but the linter specifically dislikes the direct call.
    // Standard fix: call onChange once to initialize state.
    onChange()
    
    return () => mql.removeEventListener("change", onChange)
  }, [])

  return !!isMobile
}
