'use client';

import Link from 'next/link';
import { ChevronRight, Home } from 'lucide-react';

interface BreadcrumbItem {
  label: string;
  href: string;
}

export default function Breadcrumbs({ items }: { items: BreadcrumbItem[] }) {
  return (
    <nav className="flex items-center gap-2 text-[10px] font-bold tracking-widest text-white/40 uppercase mb-8" aria-label="Breadcrumb">
      <Link href="/" className="hover:text-white transition-colors flex items-center gap-1">
        <Home className="w-3 h-3" />
        <span>Agency</span>
      </Link>
      
      {items.map((item, index) => (
        <div key={index} className="flex items-center gap-2">
          <ChevronRight className="w-3 h-3 opacity-50" />
          {index === items.length - 1 ? (
            <span className="text-white/60">{item.label}</span>
          ) : (
            <Link href={item.href} className="hover:text-white transition-colors">
              {item.label}
            </Link>
          )}
        </div>
      ))}
    </nav>
  );
}
