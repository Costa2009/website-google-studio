'use client';

import { useState } from 'react';
import { motion } from 'motion/react';
import { Send, CheckCircle2, ChevronDown } from 'lucide-react';

export default function ContactForm() {
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('loading');
    
    // Simulate API call since no backend is configured
    setTimeout(() => {
      setStatus('success');
    }, 1500);
  };

  if (status === 'success') {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-charcoal border border-emerald-accent/20 rounded-[2rem] p-12 text-center"
      >
        <div className="w-16 h-16 bg-emerald-accent text-midnight rounded-full flex items-center justify-center mx-auto mb-6 shadow-[0_0_30px_rgba(16,185,129,0.3)]">
          <CheckCircle2 className="w-8 h-8" />
        </div>
        <h3 className="text-2xl font-bold text-white mb-4">Message Sent Successfully</h3>
        <p className="text-white/60 mb-8">
          Thank you for reaching out. We&apos;ve received your enquiry and will get back to you shortly.
        </p>
        <button 
          onClick={() => setStatus('idle')}
          className="text-emerald-accent font-bold underline hover:text-white transition-colors"
        >
          Send another message
        </button>
      </motion.div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <label htmlFor="name" className="text-[10px] font-bold tracking-[0.2em] text-emerald-accent uppercase px-4">Full Name</label>
          <input
            required
            id="name"
            type="text"
            className="w-full bg-midnight border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-emerald-accent/50 transition-colors"
            placeholder="John Doe"
          />
        </div>
        <div className="space-y-2">
          <label htmlFor="business" className="text-[10px] font-bold tracking-[0.2em] text-emerald-accent uppercase px-4">Business Name</label>
          <input
            required
            id="business"
            type="text"
            className="w-full bg-midnight border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-emerald-accent/50 transition-colors"
            placeholder="Kenyan Services Ltd"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <label htmlFor="email" className="text-[10px] font-bold tracking-[0.2em] text-emerald-accent uppercase px-4">Email Address</label>
          <input
            required
            id="email"
            type="email"
            className="w-full bg-midnight border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-emerald-accent/50 transition-colors"
            placeholder="john@example.com"
          />
        </div>
        <div className="space-y-2">
          <label htmlFor="phone" className="text-[10px] font-bold tracking-[0.2em] text-emerald-accent uppercase px-4">WhatsApp / Phone</label>
          <input
            id="phone"
            type="tel"
            className="w-full bg-midnight border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-emerald-accent/50 transition-colors"
            placeholder="0700 000 000"
          />
        </div>
      </div>

      <div className="space-y-2">
        <label htmlFor="service" className="text-[10px] font-bold tracking-[0.2em] text-emerald-accent uppercase px-4">Service of Interest</label>
        <div className="relative">
          <select
            id="service"
            className="w-full bg-midnight border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-emerald-accent/50 transition-colors appearance-none"
          >
            <option value="meta-ads" className="bg-charcoal">Meta Ads Management</option>
            <option value="web-dev" className="bg-charcoal">Website Development</option>
            <option value="multiple" className="bg-charcoal">Multiple Services</option>
            <option value="not-sure" className="bg-charcoal">Not Sure Yet</option>
          </select>
          <div className="absolute right-6 top-1/2 -translate-y-1/2 pointer-events-none">
            <ChevronDown className="w-4 h-4 text-white/40" />
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <label htmlFor="website" className="text-[10px] font-bold tracking-[0.2em] text-emerald-accent uppercase px-4">Current Website (Optional)</label>
        <input
          id="website"
          type="url"
          className="w-full bg-midnight border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-emerald-accent/50 transition-colors"
          placeholder="https://example.co.ke"
        />
      </div>

      <div className="space-y-2">
        <label htmlFor="goals" className="text-[10px] font-bold tracking-[0.2em] text-emerald-accent uppercase px-4">Business Goals / Project Description</label>
        <textarea
          required
          id="goals"
          rows={4}
          className="w-full bg-midnight border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-emerald-accent/50 transition-colors resize-none"
          placeholder="Tell us about your business and what you want to achieve..."
        />
      </div>

      <div className="pt-4 text-center md:text-left">
        <p className="text-[10px] text-white/40 mb-6 px-4">
          By submitting this form, you agree to our privacy policy and consent to being contacted regarding your enquiry.
        </p>
        <button
          disabled={status === 'loading'}
          className="w-full md:w-auto px-12 py-5 bg-emerald-accent text-midnight font-black rounded-full hover:bg-white transition-all active:scale-95 flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {status === 'loading' ? 'Sending...' : 'Send Us an Enquiry'}
          <Send className="w-4 h-4" />
        </button>
      </div>
    </form>
  );
}
