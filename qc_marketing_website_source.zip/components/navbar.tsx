'use client';

import { useState, useEffect } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { Menu, X } from 'lucide-react';
import WhatsAppButton from './whatsapp-button';

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '/' },
    { name: 'About', href: '#about' },
    { name: 'Services', href: '#services' },
    { name: 'Our Work', href: '#work' },
    { name: 'Our Process', href: '#process' },
    { name: 'FAQs', href: '#faq' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 border-b ${
        scrolled 
          ? 'bg-midnight/95 backdrop-blur-md py-4 border-white/10 shadow-xl' 
          : 'bg-midnight/80 py-6 border-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark */}
        <Link href="/" className="flex items-center gap-3 shrink-0 group">
          <div className="relative w-10 h-10 overflow-hidden rounded-xl bg-charcoal border border-white/10 group-hover:border-emerald-accent/50 transition-colors">
            <Image
              src="/images/qc_logo_1793116556289.jpg"
              alt="QC Marketing Agency Logo"
              fill
              className="object-contain scale-150"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="flex flex-col">
            <span className="text-base font-black tracking-tight text-white whitespace-nowrap leading-none group-hover:text-emerald-accent transition-colors">
              QC Marketing Agency
            </span>
          </div>
        </Link>

        {/* Zone 2: Navigation Links (Desktop) */}
        <nav className="hidden xl:flex items-center gap-8 text-[10px] font-bold tracking-[0.2em] uppercase text-white/40">
          {navLinks.map((link) => (
            <Link 
              key={link.name} 
              href={link.href} 
              className="hover:text-emerald-accent transition-colors whitespace-nowrap"
            >
              {link.name}
            </Link>
          ))}
        </nav>

        {/* Zone 3: Primary Action */}
        <div className="flex items-center gap-3 shrink-0">
          <WhatsAppButton 
            label="Let's Talk Business"
            className="hidden md:flex px-5 py-2.5 bg-emerald-accent text-midnight hover:bg-white"
          />
          
          {/* Mobile Menu Toggle */}
          <button 
            className="xl:hidden p-2 text-white/60 hover:text-white transition-colors"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label={mobileMenuOpen ? "Close menu" : "Open menu"}
            aria-expanded={mobileMenuOpen}
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div className="xl:hidden fixed inset-0 top-[73px] bg-midnight z-40 px-6 py-12 animate-in fade-in slide-in-from-top-4 duration-300">
          <nav className="flex flex-col gap-6 text-xl font-black tracking-tighter text-white">
            {navLinks.map((link) => (
              <Link 
                key={link.name} 
                href={link.href} 
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-emerald-accent transition-colors"
              >
                {link.name}
              </Link>
            ))}
            <div className="pt-8 mt-auto">
              <WhatsAppButton 
                label="Message on WhatsApp"
                className="w-full py-5 text-lg"
              />
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}

