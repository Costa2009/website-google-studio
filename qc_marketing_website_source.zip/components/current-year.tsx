'use client';

import { useState, useEffect } from 'react';

export default function CurrentYear() {
  const [year, setYear] = useState<string>('2026');

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setYear(new Date().getFullYear().toString());
  }, []);

  return <>{year}</>;
}
