'use client';

import { motion, useScroll, useTransform } from 'motion/react';
import { useRef, useState, useEffect } from 'react';

export default function BackgroundMotion() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setMounted(true);
  }, []);
  
  // Subtle parallax effect for the video
  const y = useTransform(scrollYProgress, [0, 1], ['0%', '20%']);

  if (!mounted) {
    return <div className="fixed inset-0 -z-10 bg-midnight" />;
  }

  return (
    <div ref={containerRef} className="fixed inset-0 -z-10 overflow-hidden pointer-events-none bg-midnight">
      {/* Video Background Layer with Autonomous Floating Motion */}
      <motion.div 
        animate={{
          y: ['-2%', '2%', '-2%'],
          x: ['-1%', '1%', '-1%'],
        }}
        transition={{
          duration: 15,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        className="absolute -inset-[5%] w-[110%] h-[110%]"
      >
        <video
          autoPlay
          muted
          loop
          playsInline
          preload="metadata"
          className="w-full h-full object-cover opacity-60"
        >
          <source src="/assets/aistudio/Glowing_Earth_globe_floating_01e63157_d93e762e.mp4" type="video/mp4" />
          Your browser does not support the video tag.
        </video>
      </motion.div>

      {/* Dark Gradient Overlay for Readability */}
      <div className="absolute inset-0 bg-gradient-to-b from-midnight via-transparent to-midnight opacity-80" />
      <div className="absolute inset-0 bg-midnight/40" />

      {/* Subtle Gradient Texture */}
      <div className="absolute inset-0 opacity-20 bg-[radial-gradient(circle_at_50%_-20%,#10b981_0%,transparent_50%)]" />
      <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_0%_100%,#10b981_0%,transparent_40%)]" />
      
      {/* Noise Texture Overlays */}
      <div className="absolute inset-0 opacity-[0.03] mix-blend-overlay pointer-events-none select-none bg-[url('https://grainy-gradients.vercel.app/noise.svg')]" />
      
      {/* Subtle Static Elements */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.05 }}
        transition={{ duration: 2 }}
        className="absolute top-1/4 left-1/4 w-96 h-96 bg-emerald-accent blur-[120px] rounded-full"
      />
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.05 }}
        transition={{ duration: 2, delay: 0.5 }}
        className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-emerald-accent blur-[150px] rounded-full"
      />
    </div>
  );
}
