'use client';

import { MessageCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

interface WhatsAppButtonProps {
  message?: string;
  className?: string;
  variant?: 'primary' | 'secondary' | 'outline';
  label?: string;
}

export default function WhatsAppButton({ 
  message = "Hi! I found your website and would like to discuss your digital marketing or website needs.",
  className,
  variant = 'primary',
  label = "Let's Talk on WhatsApp"
}: WhatsAppButtonProps) {
  // Configurable phone number - International format without spaces/plus
  // Placeholder: 254700000000 (Kenyan format)
  const phoneNumber = "254746386377"; 
  const encodedMessage = encodeURIComponent(message);
  const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodedMessage}`;

  const variants = {
    primary: "bg-emerald-accent text-midnight hover:bg-white",
    secondary: "bg-[#25D366] text-white hover:bg-[#128C7E]",
    outline: "bg-transparent border border-white/20 text-white hover:bg-emerald-accent hover:text-midnight hover:border-emerald-accent"
  };

  return (
    <a
      href={whatsappUrl}
      target="_blank"
      rel="noopener noreferrer"
      className={cn(
        "inline-flex items-center justify-center gap-2 px-6 py-3 rounded-full font-black tracking-tight transition-all active:scale-95 text-sm",
        variants[variant],
        className
      )}
    >
      <MessageCircle className="w-4 h-4 fill-current" />
      {label}
    </a>
  );
}

